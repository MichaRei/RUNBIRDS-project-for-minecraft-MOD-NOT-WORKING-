// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports


public class BabyRunbird<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "babyrunbird"), "main");
	private final ModelPart Runbird;
	private final ModelPart upperbody;
	private final ModelPart tail;
	private final ModelPart harnaytamed;
	private final ModelPart neck;
	private final ModelPart head;
	private final ModelPart wingwest;
	private final ModelPart tip;
	private final ModelPart wingeast;
	private final ModelPart tip2;
	private final ModelPart legwest;
	private final ModelPart tibia;
	private final ModelPart foot;
	private final ModelPart toes;
	private final ModelPart legeast;
	private final ModelPart tibia2;
	private final ModelPart foot2;
	private final ModelPart toes2;

	public BabyRunbird(ModelPart root) {
		this.Runbird = root.getChild("Runbird");
		this.upperbody = this.Runbird.getChild("upperbody");
		this.tail = this.upperbody.getChild("tail");
		this.harnaytamed = this.upperbody.getChild("harnaytamed");
		this.neck = this.upperbody.getChild("neck");
		this.head = this.neck.getChild("head");
		this.wingwest = this.upperbody.getChild("wingwest");
		this.tip = this.wingwest.getChild("tip");
		this.wingeast = this.upperbody.getChild("wingeast");
		this.tip2 = this.wingeast.getChild("tip2");
		this.legwest = this.Runbird.getChild("legwest");
		this.tibia = this.legwest.getChild("tibia");
		this.foot = this.tibia.getChild("foot");
		this.toes = this.foot.getChild("toes");
		this.legeast = this.Runbird.getChild("legeast");
		this.tibia2 = this.legeast.getChild("tibia2");
		this.foot2 = this.tibia2.getChild("foot2");
		this.toes2 = this.foot2.getChild("toes2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition Runbird = partdefinition.addOrReplaceChild("Runbird", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition upperbody = Runbird.addOrReplaceChild("upperbody", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -2.0F, -4.0F, 4.0F, 4.0F, 5.0F, new CubeDeformation(-0.05F)), PartPose.offset(0.0F, -9.0F, 3.0F));

		PartDefinition baseneck_r1 = upperbody.addOrReplaceChild("baseneck_r1", CubeListBuilder.create().texOffs(0, 33).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 2.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -1.0F, -7.0F, 0.9163F, 0.0F, 0.0F));

		PartDefinition torso_r1 = upperbody.addOrReplaceChild("torso_r1", CubeListBuilder.create().texOffs(0, 9).addBox(-2.0F, -3.0326F, -1.3422F, 4.0F, 5.0F, 4.0F, new CubeDeformation(-0.03F)), PartPose.offsetAndRotation(0.0F, 0.0F, -6.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition butt_r1 = upperbody.addOrReplaceChild("butt_r1", CubeListBuilder.create().texOffs(16, 9).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 2.0F, -0.1745F, 0.0F, 0.0F));

		PartDefinition tail = upperbody.addOrReplaceChild("tail", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -1.0F, 3.0F, -0.3491F, 0.0F, 0.0F));

		PartDefinition cube_r1 = tail.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(20, 30).addBox(1.0F, 0.0F, -1.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.0F, 0.0F, 0.0F, 0.0718F, 0.3864F, 0.1886F));

		PartDefinition cube_r2 = tail.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(20, 25).addBox(-1.7133F, 0.2269F, -0.4588F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, -1.0F, 0.0718F, -0.3864F, -0.1886F));

		PartDefinition cube_r3 = tail.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(28, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.2618F, 0.0F, 0.0F));

		PartDefinition harnaytamed = upperbody.addOrReplaceChild("harnaytamed", CubeListBuilder.create(), PartPose.offset(0.0F, -2.0F, -3.0F));

		PartDefinition neck = upperbody.addOrReplaceChild("neck", CubeListBuilder.create(), PartPose.offset(0.0F, -1.0F, -8.0F));

		PartDefinition necklong_r1 = neck.addOrReplaceChild("necklong_r1", CubeListBuilder.create().texOffs(28, 5).addBox(-0.5F, -2.7412F, -0.9659F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.2618F, 0.0F, 0.0F));

		PartDefinition head = neck.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 23).addBox(0.0F, -6.0F, -4.0F, 0.0F, 5.0F, 5.0F, new CubeDeformation(0.0F))
		.texOffs(16, 17).addBox(-2.0F, -4.0F, -4.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -2.0F, 1.0F));

		PartDefinition beaktip_r1 = head.addOrReplaceChild("beaktip_r1", CubeListBuilder.create().texOffs(4, 42).addBox(-0.5F, -2.5F, -3.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 1.0F, -3.0F, 0.1745F, 0.0F, 0.0F));

		PartDefinition beakbaselarge_r1 = head.addOrReplaceChild("beakbaselarge_r1", CubeListBuilder.create().texOffs(0, 18).addBox(-2.5F, -2.0F, -2.0F, 5.0F, 2.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, -2.0F, 0.1745F, 0.0F, 0.0F));

		PartDefinition beakbaselong_r1 = head.addOrReplaceChild("beakbaselong_r1", CubeListBuilder.create().texOffs(10, 33).addBox(-1.0F, -2.0F, -2.0F, 2.0F, 2.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, -4.0F, 0.1745F, 0.0F, 0.0F));

		PartDefinition variantfeathersB_r1 = head.addOrReplaceChild("variantfeathersB_r1", CubeListBuilder.create().texOffs(32, 19).addBox(-3.0F, -2.0F, 1.0F, 6.0F, 4.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -4.0F, -1.0F, -0.5236F, 0.0F, 0.0F));

		PartDefinition wingwest = upperbody.addOrReplaceChild("wingwest", CubeListBuilder.create(), PartPose.offset(2.0F, 0.0F, -6.0F));

		PartDefinition cube_r4 = wingwest.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(18, 0).addBox(0.0F, -2.0F, -1.0F, 1.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.3927F, 0.0F, 0.0F));

		PartDefinition tip = wingwest.addOrReplaceChild("tip", CubeListBuilder.create().texOffs(40, 33).addBox(0.0F, -1.0F, 0.0F, 0.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 2.0F, 2.0F));

		PartDefinition cube_r5 = tip.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(32, 23).addBox(-1.0F, -3.0F, -2.0F, 1.0F, 4.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(1.0F, -1.0F, 1.0F, 0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r6 = tip.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(16, 41).addBox(-1.0F, -1.0F, -2.0F, 0.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, -2.0F, 2.0F, 0.3491F, 0.0F, 0.0F));

		PartDefinition cube_r7 = tip.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(16, 38).addBox(-1.0F, -1.0F, -2.0F, 0.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, -4.0F, 1.0F, 0.829F, 0.0F, 0.0F));

		PartDefinition wingeast = upperbody.addOrReplaceChild("wingeast", CubeListBuilder.create(), PartPose.offset(1.0F, 2.0F, -5.0F));

		PartDefinition cube_r8 = wingeast.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(10, 25).addBox(-1.0F, -2.0F, -1.0F, 1.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0F, -2.0F, -1.0F, -0.3927F, 0.0F, 0.0F));

		PartDefinition tip2 = wingeast.addOrReplaceChild("tip2", CubeListBuilder.create().texOffs(22, 41).addBox(0.0F, -1.0F, 0.0F, 0.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(-3.0F, 0.0F, 1.0F));

		PartDefinition cube_r9 = tip2.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(32, 30).addBox(0.0F, -3.0F, -2.0F, 1.0F, 4.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(-1.0F, -1.0F, 1.0F, 0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r10 = tip2.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(28, 41).addBox(1.0F, -1.0F, -2.0F, 0.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.0F, -2.0F, 2.0F, 0.3491F, 0.0F, 0.0F));

		PartDefinition cube_r11 = tip2.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(0, 42).addBox(1.0F, -1.0F, -2.0F, 0.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.0F, -4.0F, 1.0F, 0.829F, 0.0F, 0.0F));

		PartDefinition legwest = Runbird.addOrReplaceChild("legwest", CubeListBuilder.create(), PartPose.offset(2.0F, -8.0F, 3.0F));

		PartDefinition cube_r12 = legwest.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(32, 5).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(1.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition tibia = legwest.addOrReplaceChild("tibia", CubeListBuilder.create(), PartPose.offset(0.0F, 2.0F, -1.0F));

		PartDefinition cube_r13 = tibia.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(20, 35).addBox(0.5F, -0.4969F, -0.1467F, 1.0F, 4.0F, 2.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.7418F, 0.0F, 0.0F));

		PartDefinition foot = tibia.addOrReplaceChild("foot", CubeListBuilder.create(), PartPose.offset(1.0F, 2.0F, 3.0F));

		PartDefinition cube_r14 = foot.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(34, 41).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition toes = foot.addOrReplaceChild("toes", CubeListBuilder.create().texOffs(26, 37).addBox(-0.5F, 0.0F, -3.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 3.0F, -2.0F));

		PartDefinition cube_r15 = toes.addOrReplaceChild("cube_r15", CubeListBuilder.create().texOffs(34, 37).addBox(-0.3978F, -1.0F, -1.2235F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, 1.0F, -1.0F, 0.0F, -0.4363F, 0.0F));

		PartDefinition cube_r16 = toes.addOrReplaceChild("cube_r16", CubeListBuilder.create().texOffs(40, 0).addBox(-0.0088F, -1.0F, -0.694F, 1.0F, 1.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(-2.0F, 1.0F, -1.0F, 0.0F, 0.7854F, 0.0F));

		PartDefinition legeast = Runbird.addOrReplaceChild("legeast", CubeListBuilder.create(), PartPose.offset(-2.0F, -8.0F, 3.0F));

		PartDefinition cube_r17 = legeast.addOrReplaceChild("cube_r17", CubeListBuilder.create().texOffs(32, 12).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(-1.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition tibia2 = legeast.addOrReplaceChild("tibia2", CubeListBuilder.create(), PartPose.offset(-1.0F, 2.0F, -1.0F));

		PartDefinition cube_r18 = tibia2.addOrReplaceChild("cube_r18", CubeListBuilder.create().texOffs(40, 23).addBox(-1.5F, -0.4969F, -0.1467F, 1.0F, 4.0F, 2.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(1.0F, 0.0F, 0.0F, 0.7418F, 0.0F, 0.0F));

		PartDefinition foot2 = tibia2.addOrReplaceChild("foot2", CubeListBuilder.create(), PartPose.offset(0.0F, 2.0F, 3.0F));

		PartDefinition cube_r19 = foot2.addOrReplaceChild("cube_r19", CubeListBuilder.create().texOffs(38, 41).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition toes2 = foot2.addOrReplaceChild("toes2", CubeListBuilder.create().texOffs(0, 38).addBox(-0.5F, 0.0F, -3.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 3.0F, -2.0F));

		PartDefinition cube_r20 = toes2.addOrReplaceChild("cube_r20", CubeListBuilder.create().texOffs(8, 38).addBox(-0.6022F, -1.0F, -1.2235F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.0F, 1.0F, -1.0F, 0.0F, 0.5236F, 0.0F));

		PartDefinition cube_r21 = toes2.addOrReplaceChild("cube_r21", CubeListBuilder.create().texOffs(40, 29).addBox(-0.0374F, -1.0F, -0.9947F, 1.0F, 1.0F, 3.0F, new CubeDeformation(-0.05F)), PartPose.offsetAndRotation(1.0F, 1.0F, -1.0F, 0.0F, -1.0036F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		Runbird.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}