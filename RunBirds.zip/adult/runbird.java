// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class runbird extends EntityModel<Entity> {
	private final ModelPart Runbird;
	private final ModelPart upperbody;
	private final ModelPart tail;
	private final ModelPart harnaytamed;
	private final ModelPart neck;
	private final ModelPart head;
	private final ModelPart wingwest;
	private final ModelPart tip;
	private final ModelPart wingeast;
	private final ModelPart tip2;
	private final ModelPart legwest;
	private final ModelPart tibia;
	private final ModelPart foot;
	private final ModelPart toes;
	private final ModelPart legeast;
	private final ModelPart tibia2;
	private final ModelPart foot2;
	private final ModelPart toes2;
	public runbird(ModelPart root) {
		this.Runbird = root.getChild("Runbird");
		this.upperbody = root.getChild("upperbody");
		this.tail = root.getChild("tail");
		this.harnaytamed = root.getChild("harnaytamed");
		this.neck = root.getChild("neck");
		this.head = root.getChild("head");
		this.wingwest = root.getChild("wingwest");
		this.tip = root.getChild("tip");
		this.wingeast = root.getChild("wingeast");
		this.tip2 = root.getChild("tip2");
		this.legwest = root.getChild("legwest");
		this.tibia = root.getChild("tibia");
		this.foot = root.getChild("foot");
		this.toes = root.getChild("toes");
		this.legeast = root.getChild("legeast");
		this.tibia2 = root.getChild("tibia2");
		this.foot2 = root.getChild("foot2");
		this.toes2 = root.getChild("toes2");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData Runbird = modelPartData.addChild("Runbird", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData upperbody = Runbird.addChild("upperbody", ModelPartBuilder.create().uv(0, 0).cuboid(-3.0F, -3.0F, -6.0F, 6.0F, 6.0F, 7.0F, new Dilation(-0.05F)), ModelTransform.pivot(0.0F, -9.0F, 3.0F));

		ModelPartData baseneck_r1 = upperbody.addChild("baseneck_r1", ModelPartBuilder.create().uv(26, 7).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 2.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -2.0F, -9.0F, 0.9163F, 0.0F, 0.0F));

		ModelPartData torso_r1 = upperbody.addChild("torso_r1", ModelPartBuilder.create().uv(0, 13).cuboid(-3.0F, -3.0326F, -2.3422F, 6.0F, 6.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -7.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData butt_r1 = upperbody.addChild("butt_r1", ModelPartBuilder.create().uv(22, 13).cuboid(-2.0F, -3.0F, -3.0F, 4.0F, 5.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 2.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tail = upperbody.addChild("tail", ModelPartBuilder.create(), ModelTransform.of(0.0F, -2.0F, 3.0F, -0.3491F, 0.0F, 0.0F));

		ModelPartData cube_r1 = tail.addChild("cube_r1", ModelPartBuilder.create().uv(0, 31).cuboid(1.0F, 0.0F, -1.0F, 2.0F, 1.0F, 6.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, -1.0F, 1.0F, 0.0718F, 0.3864F, 0.1886F));

		ModelPartData cube_r2 = tail.addChild("cube_r2", ModelPartBuilder.create().uv(26, 0).cuboid(-3.0F, 0.0F, -1.0F, 2.0F, 1.0F, 6.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, -1.0F, 1.0F, 0.0718F, -0.3864F, -0.1886F));

		ModelPartData cube_r3 = tail.addChild("cube_r3", ModelPartBuilder.create().uv(0, 24).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 1.0F, 6.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -1.0F, 1.0F, 0.2618F, 0.0F, 0.0F));

		ModelPartData harnaytamed = upperbody.addChild("harnaytamed", ModelPartBuilder.create().uv(24, 51).cuboid(-3.5F, -2.5F, -3.0F, 7.0F, 1.0F, 5.0F, new Dilation(0.0F))
		.uv(18, 57).cuboid(-3.5F, -1.5F, -3.0F, 7.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -2.0F, -3.0F));

		ModelPartData neck = upperbody.addChild("neck", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -2.0F, -10.0F));

		ModelPartData necklong_r1 = neck.addChild("necklong_r1", ModelPartBuilder.create().uv(18, 45).cuboid(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, -0.2618F, 0.0F, 0.0F));

		ModelPartData head = neck.addChild("head", ModelPartBuilder.create().uv(50, 51).cuboid(0.0F, -7.0F, -4.0F, 0.0F, 6.0F, 7.0F, new Dilation(0.0F))
		.uv(22, 23).cuboid(-2.0F, -4.0F, -4.0F, 4.0F, 4.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -4.0F, 1.0F));

		ModelPartData beaktip_r1 = head.addChild("beaktip_r1", ModelPartBuilder.create().uv(28, 37).cuboid(-0.5F, -2.5F, -3.0F, 1.0F, 2.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, -4.0F, 0.1745F, 0.0F, 0.0F));

		ModelPartData beakbaselarge_r1 = head.addChild("beakbaselarge_r1", ModelPartBuilder.create().uv(16, 32).cuboid(-2.5F, -2.0F, -2.0F, 5.0F, 2.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -2.0F, 0.1745F, 0.0F, 0.0F));

		ModelPartData beakbaselong_r1 = head.addChild("beakbaselong_r1", ModelPartBuilder.create().uv(0, 38).cuboid(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, 0.1745F, 0.0F, 0.0F));

		ModelPartData variantfeathersB_r1 = head.addChild("variantfeathersB_r1", ModelPartBuilder.create().uv(0, 59).cuboid(-3.0F, -3.0F, 1.0F, 6.0F, 5.0F, 0.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -4.0F, 0.0F, -0.5236F, 0.0F, 0.0F));

		ModelPartData wingwest = upperbody.addChild("wingwest", ModelPartBuilder.create(), ModelTransform.pivot(3.0F, 0.0F, -7.0F));

		ModelPartData cube_r4 = wingwest.addChild("cube_r4", ModelPartBuilder.create().uv(32, 32).cuboid(0.0F, -2.0F, -1.0F, 2.0F, 4.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, -0.3927F, 0.0F, 0.0F));

		ModelPartData tip = wingwest.addChild("tip", ModelPartBuilder.create().uv(26, 47).cuboid(0.0F, -1.0F, 0.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 2.0F, 2.0F));

		ModelPartData cube_r5 = tip.addChild("cube_r5", ModelPartBuilder.create().uv(40, 13).cuboid(-1.0F, -3.0F, -2.0F, 2.0F, 4.0F, 3.0F, new Dilation(-0.05F)), ModelTransform.of(1.0F, -1.0F, 1.0F, 0.5236F, 0.0F, 0.0F));

		ModelPartData cube_r6 = tip.addChild("cube_r6", ModelPartBuilder.create().uv(34, 47).cuboid(-1.0F, -1.0F, -2.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, -2.0F, 2.0F, 0.3491F, 0.0F, 0.0F));

		ModelPartData cube_r7 = tip.addChild("cube_r7", ModelPartBuilder.create().uv(50, 12).cuboid(-1.0F, -1.0F, -2.0F, 1.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, -4.0F, 1.0F, 0.829F, 0.0F, 0.0F));

		ModelPartData wingeast = upperbody.addChild("wingeast", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 2.0F, -6.0F));

		ModelPartData cube_r8 = wingeast.addChild("cube_r8", ModelPartBuilder.create().uv(16, 37).cuboid(-2.0F, -2.0F, -1.0F, 2.0F, 4.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(-3.0F, -2.0F, -1.0F, -0.3927F, 0.0F, 0.0F));

		ModelPartData tip2 = wingeast.addChild("tip2", ModelPartBuilder.create().uv(42, 47).cuboid(-1.0F, -1.0F, 0.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 0.0F, 1.0F));

		ModelPartData cube_r9 = tip2.addChild("cube_r9", ModelPartBuilder.create().uv(40, 20).cuboid(-1.0F, -3.0F, -2.0F, 2.0F, 4.0F, 3.0F, new Dilation(-0.05F)), ModelTransform.of(-1.0F, -1.0F, 1.0F, 0.5236F, 0.0F, 0.0F));

		ModelPartData cube_r10 = tip2.addChild("cube_r10", ModelPartBuilder.create().uv(48, 37).cuboid(0.0F, -1.0F, -2.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, -2.0F, 2.0F, 0.3491F, 0.0F, 0.0F));

		ModelPartData cube_r11 = tip2.addChild("cube_r11", ModelPartBuilder.create().uv(50, 15).cuboid(0.0F, -1.0F, -2.0F, 1.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, -4.0F, 1.0F, 0.829F, 0.0F, 0.0F));

		ModelPartData legwest = Runbird.addChild("legwest", ModelPartBuilder.create(), ModelTransform.pivot(2.0F, -8.0F, 3.0F));

		ModelPartData cube_r12 = legwest.addChild("cube_r12", ModelPartBuilder.create().uv(28, 40).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 3.0F, new Dilation(-0.05F)), ModelTransform.of(1.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData tibia = legwest.addChild("tibia", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 2.0F, -1.0F));

		ModelPartData cube_r13 = tibia.addChild("cube_r13", ModelPartBuilder.create().uv(16, 24).cuboid(0.5F, -0.4969F, -0.1467F, 1.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, 0.6109F, 0.0F, 0.0F));

		ModelPartData foot = tibia.addChild("foot", ModelPartBuilder.create(), ModelTransform.pivot(1.0F, 2.0F, 3.0F));

		ModelPartData cube_r14 = foot.addChild("cube_r14", ModelPartBuilder.create().uv(42, 0).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData toes = foot.addChild("toes", ModelPartBuilder.create().uv(40, 27).cuboid(-0.5F, 0.0F, -5.0F, 1.0F, 1.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 3.0F, -1.0F));

		ModelPartData cube_r15 = toes.addChild("cube_r15", ModelPartBuilder.create().uv(42, 7).cuboid(2.5F, -1.0F, -3.0F, 1.0F, 1.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 1.0F, -2.0F, 0.0F, -0.2618F, 0.0F));

		ModelPartData cube_r16 = toes.addChild("cube_r16", ModelPartBuilder.create().uv(48, 41).cuboid(2.5F, -1.0F, -2.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(-4.0F, 1.0F, -1.0F, 0.0F, 0.3054F, 0.0F));

		ModelPartData legeast = Runbird.addChild("legeast", ModelPartBuilder.create(), ModelTransform.pivot(-2.0F, -8.0F, 3.0F));

		ModelPartData cube_r17 = legeast.addChild("cube_r17", ModelPartBuilder.create().uv(38, 40).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 3.0F, new Dilation(-0.05F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData tibia2 = legeast.addChild("tibia2", ModelPartBuilder.create(), ModelTransform.pivot(-1.0F, 2.0F, -1.0F));

		ModelPartData cube_r18 = tibia2.addChild("cube_r18", ModelPartBuilder.create().uv(50, 0).cuboid(-1.5F, -0.4969F, -0.1467F, 1.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.6109F, 0.0F, 0.0F));

		ModelPartData foot2 = tibia2.addChild("foot2", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 2.0F, 3.0F));

		ModelPartData cube_r19 = foot2.addChild("cube_r19", ModelPartBuilder.create().uv(10, 45).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData toes2 = foot2.addChild("toes2", ModelPartBuilder.create().uv(0, 44).cuboid(-0.5F, 0.0F, -5.0F, 1.0F, 1.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 3.0F, -1.0F));

		ModelPartData cube_r20 = toes2.addChild("cube_r20", ModelPartBuilder.create().uv(44, 32).cuboid(-3.5F, -1.0F, -3.0F, 1.0F, 1.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 1.0F, -2.0F, 0.0F, 0.2618F, 0.0F));

		ModelPartData cube_r21 = toes2.addChild("cube_r21", ModelPartBuilder.create().uv(0, 49).cuboid(-3.5F, -1.0F, -2.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(4.0F, 1.0F, -1.0F, 0.0F, -0.3054F, 0.0F));
		return TexturedModelData.of(modelData, 64, 64);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		Runbird.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}